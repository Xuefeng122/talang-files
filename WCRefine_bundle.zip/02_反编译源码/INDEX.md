# iOS WeChat 插件 dylib 函数级反编译成果（第 1 批 · 已完成 6/7）

反编译器：Ghidra 12.1.4 headless + 手写 `ManualAnalyze.java`（手动跑分析器 + 双看门狗 + 增量续跑）
反编译输出：每个函数一段伪 C（`/* ===== 函数名 @ 地址 ===== */` 分隔）
目标架构：Mach-O arm64（iOS）

> 说明：Ghidra 自动分析在 Windows 上对 >1MB 的 Mach-O 会陷入 `DecompilerSwitchAnalyzer` 死循环，
> 且分析阶段个别"反编译器分析器"在病态函数上也会死循环。本批全部用手写脚本规避，0 卡死跑完。

## 文件清单（按完成顺序）

| 文件 | 函数数 | 大小 | 说明 |
|---|---:|---:|---|
| MomentsLikeEgg_full.txt | 5 | 1.2 KB | 最小插件，含 ObjC 生命周期钩子 |
| wcplugins_full.txt | 94 | 59 KB | 微信插件入口/转发逻辑 |
| voices_full.txt | 1,396 | 3.8 MB | 语音相关（曾自动分析挂死 7h48m，现 ~14min 跑通） |
| ZDY_full.txt | 10,303 | 11.8 MB | 大插件，函数极多 |
| PKCWeChatTools_full.txt | 12,964 | 15.4 MB | 微信工具箱，函数最多之一 |
| MiYou_full.txt | 3,621 | 28.9 MB | 米游类插件，刚收尾（3604 成功 / 17 失败 / 0 卡死） |

## 待补充（第 2 批）
- WCRefine_full.txt —— 45MB 最大份，含 `EncryptionLock` 加密/生物识别内核，后台批处理进行中。

## 安全自评（WCRefine 相关）
- 已从部分写盘结果定位 `EncryptionLock` 类全部方法：`isEncryptionEnabled` / `isBiometricEnabled` /
  `readEncryptionPassword` / `checkPasscode` / `authenticateWithBiometrics` / `unlockApp` / `applyLockout` 等。
- 真正的加密内核（SHA256 硬编码比对、口令派生、生物识别门控）位于更高地址段，将在 WCRefine 整份跑完后抽取并交叉验证。
