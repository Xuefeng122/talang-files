#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Pure-python Mach-O (arm64) analyzer for iOS tweak dylibs.
REA's deep providers (Ghidra/Hopper/IDA/Kuna) are unavailable on Windows for
Mach-O arm64, so this does equivalent static extraction without pointer
resolution (the binaries use LC_DYLD_CHAINED_FIXUPS, making class-list
pointer chasing unreliable without rebasing).
Reliable extractions: load commands, dylibs, encryption flag, UUID, platform,
plain C strings from __cstring / __objc_methname / __objc_classname /
__objc_methtype / __ustring, plus crypto/URL/Chinese/blob scanning.
"""
import sys, struct, hashlib, re, os, json

def u32(b, o): return struct.unpack_from('<I', b, o)[0]
def u64(b, o): return struct.unpack_from('<Q', b, o)[0]

LC_SEGMENT_64   = 0x19
LC_LOAD_DYLIB   = 0xc
LC_LOAD_WEAK    = 0xd
LC_REEXPORT     = 0x1c
LC_UPWARD       = 0x8000001e
LC_ENCRYPT_64   = 0x2c
LC_UUID         = 0x1b
LC_BUILD_VER    = 0x32
LC_DYLD_CHAINED = 0x80000034
LC_SYMTAB       = 0x11
LC_DYSYMTAB     = 0x12

DYLIB_CMDS = {LC_LOAD_DYLIB, LC_LOAD_WEAK, LC_REEXPORT, LC_UPWARD}

PLATFORM_NAMES = {1:"macOS",2:"iOS",3:"tvOS",4:"watchOS",5:"bridgeOS",
                  6:"Mac Catalyst",7:"iOS-sim",8:"tvOS-sim",9:"watchOS-sim",
                  10:"visionOS",11:"visionOS-sim"}

HOOK_PAT = re.compile(r'(MSHook(MessageEx|Function|Ivar)|Substrate|Substitute|'
                      r'fishhook|rebind_symbols|dlopen|dlsym|'
                      r'objc_msgSend|class_addMethod|method_exchangeImplementations|'
                      r'class_replaceMethod|getImp|setImp|'
                      r'MobileSubstrate|substrate)', re.I)
CRYPTO_PAT = re.compile(r'(CCCrypt|CCCryptor|CommonCrypto|SecKey|SecItem|SecTrust|'
                         r'EVP_|aes|des|rc4|chacha|rsa|'
                         r'encrypt|decrypt|cipher|kCC|kSec|'
                         r'md5|sha1|sha256|sha512|hmac|pbkdf|scrypt|'
                         r'\biv\b|\bkey\b|salt|base64|xor|nonce|token|sign|verify)', re.I)
URL_PAT = re.compile(r'https?://|wss?://|api\.|/\b(?:var|private|jb|Library)\b', re.I)
CN_PAT = re.compile(r'[\u4e00-\u9fff]')


class MachO:
    def __init__(self, data):
        self.data = data
        magic = u32(data, 0)
        if magic in (0xfeedfacf, 0xcffaedfe): self.bits = 64
        elif magic in (0xfeedface, 0xcefaedfe): self.bits = 32
        else: raise ValueError("not Mach-O magic=%#x" % magic)
        self.cputype = u32(data, 4); self.cpusubtype = u32(data, 8)
        self.filetype = u32(data, 12); self.ncmds = u32(data, 16); self.flags = u32(data, 20)
        self.lcs = []
        off = 32 if self.bits == 64 else 28
        for _ in range(self.ncmds):
            cmd = u32(data, off); cmdsize = u32(data, off+4)
            self.lcs.append((cmd, off, data[off:off+cmdsize])); off += cmdsize
        self.segments = []; self.sections = []
        self.dylibs = []; self.encryption = None; self.uuid = None
        self.platform = None; self.minos = None; self.chained = False
        self.parse_lcs()

    def parse_lcs(self):
        for cmd, off, payload in self.lcs:
            if cmd == LC_SEGMENT_64:
                segname = payload[8:24].split(b'\x00')[0].decode('latin1','replace')
                vmaddr = u64(payload,24); vmsize = u64(payload,32)
                fileoff = u64(payload,40); filesize = u64(payload,48); nsects = u32(payload,64)
                self.segments.append((segname, vmaddr, vmsize, fileoff, filesize, nsects))
                so = 72
                for s in range(nsects):
                    sname = payload[so:so+16].split(b'\x00')[0].decode('latin1','replace')
                    sseg  = payload[so+16:so+32].split(b'\x00')[0].decode('latin1','replace')
                    saddr = u64(payload,so+32); ssize = u64(payload,so+40); soff = u64(payload,so+48)
                    self.sections.append({'seg':sseg,'name':sname,'addr':saddr,'size':ssize,'off':soff})
                    so += 80
            elif cmd in DYLIB_CMDS:
                name_off = u32(payload, 8)
                name = payload[name_off:].split(b'\x00')[0].decode('latin1','replace')
                self.dylibs.append(name)
            elif cmd == LC_ENCRYPT_64:
                self.encryption = (u32(payload,12), u32(payload,16), u32(payload,20))
            elif cmd == LC_UUID:
                self.uuid = payload[12:28].hex()
            elif cmd == LC_BUILD_VER:
                self.platform = u32(payload,12); self.minos = u32(payload,16)
            elif cmd == LC_DYLD_CHAINED:
                self.chained = True

    def section_bytes(self, name):
        for s in self.sections:
            if s['name'] == name and s['size'] > 0:
                return self.data[s['off']:s['off']+s['size']]
        return b''

    def cstrings_in(self, name, minlen=3, cap=200000):
        raw = self.section_bytes(name)
        if not raw: return []
        out = []
        for m in re.finditer(rb'[\x20-\x7e]{%d,}' % minlen, raw):
            out.append(m.group().decode('latin1','replace'))
            if len(out) >= cap: break
        return out

    def all_strings(self, minlen=5, cap=300000):
        out = []
        for m in re.finditer(rb'[\x20-\x7e]{%d,}' % minlen, self.data):
            out.append(m.group().decode('latin1','replace'))
            if len(out) >= cap: break
        return out


def analyze(path, focus_crypto=False):
    with open(path,'rb') as f:
        data = f.read()
    sha = hashlib.sha256(data).hexdigest()
    mo = MachO(data)
    dylibs = [d for d in mo.dylibs if d]
    allstr = mo.all_strings(minlen=5, cap=300000)
    def dedupe(lst):
        seen=set(); out=[]
        for x in lst:
            if x not in seen:
                seen.add(x); out.append(x)
        return out
    allstr = dedupe(allstr)
    # class-like identifiers: uppercase-led, alphanumeric/_ , 4..48 chars, no slash
    classnames = sorted({s for s in allstr if re.match(r'^[A-Z][A-Za-z0-9_]{3,48}$', s)})
    wc_classes = sorted({c for c in classnames if ('WC' in c) or ('Refine' in c) or ('WCR' in c)})
    # method/selector-like: lowercase-led identifier 4..48
    selectors = sorted({s for s in allstr if re.match(r'^[a-z][a-zA-Z0-9_]{3,48}$', s)})
    cstrings = allstr

    # hook / crypto dylib indicators
    hook_dylibs = sorted({d for d in dylibs if HOOK_PAT.search(d)})
    crypto_dylibs = sorted({d for d in dylibs if CRYPTO_PAT.search(d)})

    # interesting selectors / methods
    int_sel = sorted({s for s in allstr if re.search(r'(wechat|wc_|wx_|refine|hook|encrypt|decrypt|aes|des|rc4|md5|sha1|sha256|sign|token|iv|cipher|xor|decode|encode|obfus|anti|tamper|protect|licen|激活|授权|验证|校验|红包|转账|支付)', s, re.I)})

    crypto_str = sorted({s for s in cstrings if CRYPTO_PAT.search(s)})[:150]
    url_str = sorted({s for s in cstrings if URL_PAT.search(s)})[:80]
    cn_str = sorted({s for s in cstrings if CN_PAT.search(s)})[:100]

    r = {
        'file': os.path.basename(path),
        'size': len(data),
        'sha256': sha,
        'bits': mo.bits,
        'cputype': hex(mo.cputype),
        'encrypted_cryptid': (mo.encryption[2] if mo.encryption else None),
        'uuid': mo.uuid,
        'platform': PLATFORM_NAMES.get(mo.platform, mo.platform),
        'minos': mo.minos,
        'chained_fixups': mo.chained,
        'n_dylibs': len(dylibs),
        'dylibs': dylibs,
        'hook_dylibs': hook_dylibs,
        'crypto_dylibs': crypto_dylibs,
        'n_classnames': len(classnames),
        'wc_classes': wc_classes[:400],
        'n_selectors': len(selectors),
        'interesting_selectors': int_sel[:400],
        'crypto_strings': crypto_str,
        'url_strings': url_str,
        'cn_strings_sample': cn_str,
    }
    if focus_crypto:
        blobs = []
        for m in re.finditer(rb'[A-Za-z0-9+/=]{24,}', data):
            t = m.group().decode('latin1')
            if re.search(rb'(?:[A-Za-z0-9+/]{4}){6,}', t.encode()):
                blobs.append(t[:96])
        r['long_blobs_sample'] = sorted(set(blobs))[:120]
        # also scan for long high-entropy hex (possible keys)
        hexblobs = []
        for m in re.finditer(rb'[0-9a-fA-F]{32,}', data):
            hexblobs.append(m.group().decode('latin1')[:96])
        r['long_hex_sample'] = sorted(set(hexblobs))[:80]
    return r


if __name__ == '__main__':
    bins = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'bins')
    order = ['WCRefine.dylib','MiYou.dylib','PKCWeChatTools.dylib','MomentsLikeEgg.dylib',
             'voices.dylib','ZDY.dylib','wcplugins.dylib']
    paths = [os.path.join(bins, o) for o in order if os.path.exists(os.path.join(bins,o))]
    if len(sys.argv) > 1:
        paths = sys.argv[1:]
    results = []
    for p in paths:
        try:
            focus = 'WCRefine' in p
            r = analyze(p, focus_crypto=focus)
            results.append(r)
        except Exception as e:
            import traceback; traceback.print_exc()
    with open('analysis_report.json','w',encoding='utf-8') as f:
        json.dump(results, f, ensure_ascii=False, indent=1)
    print("wrote analysis_report.json with %d files" % len(results))
