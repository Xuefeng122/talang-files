#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Targeted highlights: short curated strings only, truncated, no giant blobs."""
import json, re, os

ROOT = os.path.dirname(os.path.abspath(__file__))
res = json.load(open(os.path.join(ROOT, "analysis_report.json"), encoding="utf-8"))
byname = {r['file']: r for r in res}
BINS = os.path.join(ROOT, "bins")

def raw(name):
    p = os.path.join(BINS, name)
    return open(p,'rb').read() if os.path.exists(p) else b''

def t(s, n=160):
    s = str(s)
    return s if len(s) <= n else s[:n] + "…[%d]" % len(s)

def cjk_samples(data, n=30, minrun=2):
    out=[]
    for m in re.finditer(rb'(?:[\xe4-\xe9][\x80-\xbf][\x80-\xbf]){%d,}' % minrun, data):
        try: out.append(m.group().decode('utf-8'))
        except: pass
        if len(out)>=n: break
    return out

def shortlist(r):
    # curated short symbol strings only
    items = list(r.get('wc_classes', [])) + list(r.get('interesting_selectors', []))
    out=[]
    for s in items:
        if isinstance(s,str) and 3 <= len(s) <= 120 and '\n' not in s:
            out.append(s)
    return out

print("#"*78)
print("# WCRefine.dylib  --  ENCRYPTION / CHALLENGE DEEP DIVE")
print("#"*78)
d = byname['WCRefine.dylib']
sl = shortlist(d)
enc = sorted({s for s in sl if re.search(r'[Ee]ncrypt|[Ss]ecure', s)})
print("\n[Encryption / Secure symbols]  count=%d" % len(enc))
for s in enc[:50]: print("  ", t(s))
bio = sorted({s for s in sl if re.search(r'Face|Touch|Biometric|LAContext|LocalAuth|指纹|面容|生物', s, re.I)})
print("\n[Biometric / LocalAuthentication refs]  count=%d" % len(bio))
for s in bio[:30]: print("  ", t(s))
kw = sorted({s for s in sl if re.search(r'\b(AES|DES|RC4|ChaCha|RSA|kCC|CCCrypt|pbkdf|hmac|sha256|md5|salt|nonce|token|sign|verify|key|iv|cipher)\b', s, re.I)})
print("\n[Crypto keyword strings]  count=%d ; sample:" % len(kw))
for s in kw[:50]: print("  ", t(s))
hexs = d.get('long_hex_sample', [])
sha = [h for h in hexs if len(re.sub(r'[^0-9a-fA-F]','',h))==64]
print("\n[64-hex SHA256-like hashes] count=%d ; sample:" % len(sha))
for h in sha[:12]: print("  ", h)
print("\n[Interesting URLs / endpoints]")
for u in d.get('url_strings',[])[:50]: print("  ", t(u))
cjk = cjk_samples(raw('WCRefine.dylib'), 30)
print("\n[Chinese (UTF-8) samples] count=%d" % len(cjk))
for s in cjk[:30]: print("  ", t(s, 60))

print("\n" + "#"*78)
print("# PER-PLUGIN  own classes (WC*/Refine*) + feature selectors")
print("#"*78)
for name in ['WCRefine.dylib','MiYou.dylib','PKCWeChatTools.dylib','MomentsLikeEgg.dylib',
            'voices.dylib','ZDY.dylib','wcplugins.dylib']:
    if name not in byname: continue
    r = byname[name]
    wcs = [c for c in r.get('wc_classes',[]) if re.match(r'^[A-Za-z][A-Za-z0-9_]{3,48}$', c) and not c.startswith('0')]
    ints = [s for s in r.get('interesting_selectors',[]) if 3<=len(s)<=120][:20]
    print("\n=== %s  (wc_classes=%d, selectors=%d) ===" % (name, len(r.get('wc_classes',[])), r.get('n_selectors')))
    print("  classes:", ", ".join(wcs[:35]))
    print("  feat:", ", ".join(ints[:20]))
