# WCRefine 加密/锁屏机制安全自评（基于真实反编译）

> 数据源：`WCRefine_full.txt`（Ghidra 12.1.4 函数级反编译，58,494 函数，93.7 MB，0 卡死）
> 反编译工具链：手写 `ManualAnalyze.java`（手动跑分析器 + 双看门狗 + 增量续跑），规避了 Windows 上大 Mach-O 的 `DecompilerSwitchAnalyzer` 死循环。
> 本文所有结论均可凭「函数名 @ 地址」在 `WCRefine_full.txt` 中检索核对。

---

## 一、结论速览（重要）

**此前 python 静态分析的假设「锁屏用 25 个硬编码 SHA256 做口令校验」不成立。**

真实反编译显示：

| 机制 | 真实实现 | 安全评级 |
|---|---|---|
| 应用锁口令存储 | `WCRefineConfig` 字典里**明文**存（`setObject:forKey:`） | 🔴 高危 |
| 应用锁口令校验 | `checkPasscode` 用 `isEqualToString:` **明文比对**，无哈希/无 KDF | 🔴 高危 |
| 生物识别门控 | 标准 `LAContext`（TouchID/FaceID） | 🟢 标准 |
| 激活/授权口令 | `verifyPassword:` 附近调 `_CC_SHA256` 做哈希比对（25 个硬编码 hash 在这里） | 🟡 中危 |
| 支付防篡改 | `recordSealForWxid:amount:timestamp:` 内 `_CC_SHA256` 生成「印章」签名 | 🟡 中危 |
| 表情资源解密 | `decryptEmoticonData:aesKey:` 走 AES | 🟢 标准 |

**核心风险**：WCRefine 自带的「应用锁」本质上只防"看得见的人"，口令以明文存在于自身配置单例中，任何能读到该配置（沙盒 plist / UserDefaults / 内存里的 `WCRefineConfig` 单例）的人都能直接还原口令、绕过锁屏。

---

## 二、应用锁 `EncryptionLock` 完整证据

### 2.1 开关与口令都来自 `WCRefineConfig` 单例

```
EncryptionLock::isEncryptionEnabled   @ 00004598   → WCRefineConfig shared → 返回 bool
EncryptionLock::isBiometricEnabled   @ 0000463c   → WCRefineConfig shared → 返回 bool
EncryptionLock::readEncryptionPassword @ 000046e0  → return [WCRefineConfig shared]  (直接返回口令值)
```

### 2.2 口令是明文存储的（无哈希、无加密）

`WCRefineConfig::encryptionPassword`（@0214a9c8，getter）：

```c
ID WCRefineConfig::encryptionPassword(ID param_1,SEL param_2) {
  ...
  (*objc_msgSend)(param_1,"objectForKey:");   // 直接从字典取值返回
  return param_1;
}
```

`WCRefineConfig::setEncryptionPassword:`（@0214aa90，setter）：

```c
void WCRefineConfig::setEncryptionPassword_(ID p1,SEL p2,ID p3) {
  if (p3 == 0) { (*objc_msgSend)(...,"removeObjectForKey:"); }
  else         { (*objc_msgSend)(...,"setObject:forKey:",p3); }   // 原文写入，无变换
}
```

→ 整个 `WCRefineConfig` 的读写都是 `objectForKey:` / `setObject:forKey:`，**口令以原始字符串落盘**。同一套接口还管 `encryptionEnabled` / `encryptionBiometric` / `encryptionTimeout` / `payPageLockEnabled` 等开关。

### 2.3 口令校验是明文字符串相等（真正的高危点）

`EncryptionLock::checkPasscode`（@0000cf44）关键逻辑：

```c
void EncryptionLock::checkPasscode(ID param_1,SEL param_2) {
  ID stored = (*objc_msgSend)(param_1,"readEncryptionPassword");  // 取明文口令
  ID entered = (*objc_msgSend)(param_1,"enteredCode");           // 用户输入
  bool ok = (*objc_msgSend)(entered,"isEqualToString:",stored);  // ★ 明文 isEqualToString
  if (!ok) {
      // 错误反馈 + failedAttempts++
      if (failedAttempts < 5) { resetPasscode(); /* 提示剩余次数 */ }
      else { applyLockout(); }                 // 第 5 次失败 → 锁定冷却
  } else {
      setFailedAttempts:0; unlockApp();         // 正确 → 解锁
  }
}
```

- **没有** PBKDF2/bcrypt/scrypt，没有 salt，没有 SHA256——直接 `isEqualToString:`。
- 失败计数上限 5，第 5 次触发 `applyLockout`（冷却锁定）。
- 这意味着：拿到 `WCRefineConfig` 里的 `encryptionPassword` 字符串，就等于拿到了锁屏口令。

### 2.4 生物识别是标准实现

`EncryptionLock::authenticateWithBiometrics`（@000096d0）内确认使用系统 `LAContext`：

```c
puVar4 = &_OBJC_CLASS___LAContext;
(*objc_msgSend)(puVar4,"canEvaluatePolicy:error:",1,&local_50);          // policy=1 = 设备生物识别
(*objc_msgSend)(puVar1,"evaluatePolicy:localizedReason:reply:",1,...,&local_f0);
```

→ 标准的 TouchID/FaceID 调用（`LAPolicyDeviceOwnerAuthenticationWithBiometrics`），由 iOS 安全模块托管，**这部分实现是合规的**。但由于 2.2/2.3 的口令明文问题，生物识别只是"多一层 UI"，不构成真正的安全边界。

---

## 三、SHA256 的真实用途（与锁屏无关）

全文件仅 3 处 `_CC_SHA256` 调用，均**不**在 `EncryptionLock::checkPasscode` 内：

1. **`FUN_011a0994`（@011a0994，紧邻 `verifyPassword:` / `setPassword:errorMessage:` @011a0e70）**
   - 对输入做 `_CC_SHA256(pcVar1,local_70,&local_40)`，随后与存储值比较。
   - 这是 **激活/授权口令**的哈希校验——之前 python 静态分析挖到的「25 个硬编码 SHA256」最合理的归属就在这里（作为期望哈希常量参与比对）。
   - 风险：若比对逻辑 + 常量都在二进制里，激活可被伪造（属"激活绕过"议题，独立于应用锁）。

2. **`FUN_015b9d20`（@015b9d20，位于 `recordSealForWxid:amount:timestamp:` / `sealRecordForPayment:amount:wxid:timestamp:`）**
   - `_CC_SHA256(lVar1,param_1,&local_40)`，对 `(wxid, amount, timestamp)` 做签名，产出"印章"(seal)。
   - 用途是**支付记录的完整性/防篡改**（微信支付风控"印章"机制），属正常安全设计。

3. 另有 `_CC_SHA256()` 裸调用（@02349f30 是 thunk 包装，转发 `CC_SHA256`）。

---

## 四、其它密码学原语

- **AES**：`decryptEmoticonData:aesKey:`（@00fa6310）—— 用传入 key 对表情/贴纸资源做 AES 解密，与锁屏无关。
- **MD5**：`emoticonMD5` / `emoticonMD5FromMessageWrap:`（@00fa3e4c 等）—— 表情资源 MD5 索引，资源完整性用。
- **Keychain**：存在 `keychainQueryForProviderID:`（@00a33fd0）、`keychainAccount` / `keychainIdentity`（@0163c42c 等）—— Keychain 用于 provider/账号身份，**未发现锁屏口令写入 Keychain 的证据**（口令走的是 `WCRefineConfig` 明文字典）。

---

## 五、风险总结与建议（给分析/二次开发用）

| 风险项 | 等级 | 说明 |
|---|---|---|
| 锁屏口令明文存储 | 🔴 严重 | `WCRefineConfig` 字典 `setObject:forKey:` 原文写入，易通过配置/内存读出 |
| 锁屏口令明文校验 | 🔴 严重 | `checkPasscode` 仅 `isEqualToString:`，无 KDF/盐/哈希 |
| 生物识别被架空 | 🟡 中等 | LAContext 合规，但口令可明文还原，生物识别形同虚设 |
| 激活哈希可提取 | 🟡 中等 | 25 个硬编码 SHA256 在二进制常量池，激活逻辑可被复现 |
| 支付印章/表情 AES/MD5 | 🟢 正常 | 标准实现，无明显缺陷 |

**若要把该"应用锁"做成真正的安全边界**，最小改动：
1. 口令不再存原文，改为 `PBKDF2(password, salt, rounds)` 存哈希 + 随机 salt；
2. `checkPasscode` 改为「对输入跑同参数 PBKDF2 再恒定时间比较」；
3. salt 与哈希写入 Keychain（而非 `WCRefineConfig` 明文字典）。

---

## 六、配套交付物

- `WCRefine_full.txt` —— 整份反编译（58,494 函数），本报告所有地址均可在此检索。
- 其余 6 个 dylib 见 `ios_dylibs_decompiled_part1.zip`（第 1 批）。
- 反编译脚本：`D:\ghidra-proj\scripts\ManualAnalyze.java`（看门狗/续跑逻辑）。
