# 在 Windows 上对 iOS Mach-O（arm64 dylib）做深度逆向分析

## 结论先行
REA 在 Windows 上**不能**做 Mach-O 深度分析（Ghidra/Hopper/IDA 四个后端全未配置，且 REA 的 Windows 适配只收 PE、明确排除 Mach-O；REA 的 MCP 又是本地 stdio、不能跨机连）。
但 **Ghidra 12.1.4 本身是跨平台 Java 程序，在 Windows 上能直接打开 Mach-O arm64 做反编译/交叉引用/ObjC 类恢复**——所以"在 Windows 上做 Mach-O 深度分析"完全可行，只是不走 REA，而是 **Ghidra 独立使用**。

已在本机落地验证：对 `MomentsLikeEgg.dylib` 成功完成导入→自动分析（`Applied data type archive: mac_osx` → `Analysis succeeded`），并用后处理脚本导出了真实反编译 C 代码。

## 已安装环境
- Ghidra 12.1.4：`D:\tools\ghidra_12.1.4_PUBLIC\`
- Temurin JDK 21：`D:\tools\jdk-21.0.8+9\`
- 环境变量（每次分析前设）：`JAVA_HOME=D:\tools\jdk-21.0.8+9`，并把它加入 `PATH`
- 项目/脚本目录：`D:\ghidra-proj\`

## 一键使用（推荐）
双击 `D:\ghidra-proj\analyze_dylib.bat`，或命令行：
```
analyze_dylib.bat "<dylib路径>" [输出txt] [关键词过滤]
```
示例（只导出名字/代码里含 Encrypt 的函数）：
```
analyze_dylib.bat "C:\Users\Administrator\WorkBuddy\2026-11-01-13-35-30\ios-plugins-analysis\bins\WCRefine.dylib" wc.txt Encrypt
```
- 不加关键词 = 导出全部函数的反编译 C（大文件会很慢、很大）
- 关键词 = 大小写不敏感的子串，只保留反编译体内含该词的函数（用于精准挖加密/授权逻辑）

## 手动无头命令（Git Bash 中，绝对路径）
```bash
export JAVA_HOME="/d/tools/jdk-21.0.8+9"
export PATH="$JAVA_HOME/bin:$PATH"
/d/tools/ghidra_12.1.4_PUBLIC/support/analyzeHeadless \
  /d/ghidra-proj PROJNAME \
  -import "C:/.../bins/xxx.dylib" \
  -scriptPath "D:/ghidra-proj/scripts" \
  -postScript DumpDecomp.java "D:/ghidra-proj/out.txt" "" 2000
```

## 踩坑记录（重要）
1. **Ghidra 12.1.4 的 `AnalyzeHeadless` 没有 `-analyze` 选项**。默认导入即分析，用 `-noanalysis` 才跳过。加 `-analyze` 会被 `-import` 当成文件名吃掉，报 `Bad argument` 或"找不到文件"。
2. **用绝对路径调用 `support/analyzeHeadless`**；相对 `./` 会让参数错位。Bash 工具禁止 `cmd.exe`，但可直接跑这个 POSIX 脚本（它内部用 `launch.sh` 找 java）。
3. **后处理脚本用 `.java` GhidraScript**（Ghidra 即时编译），不要用 `.py`（需 PyGhidra，本机未启用）。
4. **自定义脚本必须加 `-scriptPath <目录>`**，并按脚本**名**引用（如 `-postScript DumpDecomp.java`），不能用路径。

## 脚本说明
- `scripts/DumpDecomp.java`：反编译全部/过滤函数，导出 C。参数 `out.txt [关键词] [最多函数数]`。
- `scripts/DumpNamed.java`：只反编译"函数名"匹配正则的函数（更快更准，用于按符号名挖特定逻辑）。参数 `out.txt <名称正则> [最多匹配数]`。

## 已知边界
- 这是**纯静态**分析。反编译质量依赖 Ghidra 的 Mach-O/ObjC/Swift 分析器；strip 过的符号、哑名函数（`FUN_xxxx`）需要结合字符串/交叉引用人工判读。
- 想要 REA 那套"证据包/工作流集成 + Hopper/IDA 伪代码"，仍得在 **macOS** 上整套部署（WorkBuddy+REA+Ghidra），那是 REA 官方验证过的唯一干净路径。
